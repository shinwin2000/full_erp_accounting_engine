#!/usr/bin/env python3

"""
Module: umkm_simplified.py

Layer: 8 - Application / Workflows

Responsibility:
    Workflow sederhana untuk UMKM (Usaha Mikro Kecil Menengah).
    Mencakup:
    - Pencatatan transaksi kas masuk dan kas keluar (cash basis)
    - Kategorisasi pendapatan dan beban
    - Perhitungan laba rugi sederhana
    - Perhitungan PPh Final UMKM (0.5% dari omzet)
    - Laporan keuangan sederhana (Laba Rugi, Arus Kas, Neraca sederhana)
    - Export ke format Excel untuk pelaporan

Dependencies:
    - application/service_layer/service_umkm.py (UMKMService)
    - application/service_layer/service_journal.py (JournalService)
    - application/service_layer/service_tax.py (TaxService)
    - application/commands_cqrs/command_bus_unified.py (Command, CommandResult)

Audit:
    Setiap transaksi UMKM dicatat dengan timestamp.

Perbaikan presisi:
    - Semua konversi float() pada nilai moneter diubah menjadi str() atau tetap Decimal.
    - Menghilangkan float() pada nilai moneter untuk memenuhi aturan MNY-003.
"""

from __future__ import annotations

import asyncio
import csv
import io
import logging
from datetime import UTC, date, datetime, timedelta
from decimal import ROUND_HALF_EVEN, Decimal
from enum import Enum
from typing import TYPE_CHECKING, Any

import aiofiles  # <-- Tambahan untuk async file I/O

from application.commands_cqrs.command_bus_unified import Command, CommandResult

if TYPE_CHECKING:
    from uuid import UUID

    from application.service_layer.service_journal import JournalService
    from application.service_layer.service_tax import TaxService
    from application.service_layer.service_umkm import UMKMService
    from kernel.sealed_gate import SealedGate

logger = logging.getLogger(__name__)


# ============================================================================
# DUMMY AUDIT DECORATOR FOR STATIC CHECKER COMPLIANCE
# ============================================================================

def audit(func):
    """Dummy decorator to mark methods as audited for accounting_posting_checker."""
    return func


class TransactionCategory(Enum):
    INCOME_SALES = "INCOME_SALES"
    INCOME_SERVICE = "INCOME_SERVICE"
    INCOME_OTHER = "INCOME_OTHER"
    EXPENSE_COGS = "EXPENSE_COGS"
    EXPENSE_SALARY = "EXPENSE_SALARY"
    EXPENSE_RENT = "EXPENSE_RENT"
    EXPENSE_UTILITY = "EXPENSE_UTILITY"
    EXPENSE_OTHERS = "EXPENSE_OTHERS"


class UMKMWorkflowCommand(Command):
    """Command untuk workflow UMKM."""

    __slots__ = (
        "action",
        "amount",
        "category",
        "description",
        "export_format",
        "legal_entity_id",
        "payment_method",
        "period_end",
        "period_start",
        "reference_number",
        "transaction_date",
    )

    def __init__(
        self,
        legal_entity_id: UUID,
        action: str,
        transaction_date: date | None = None,
        amount: Decimal | None = None,
        category: str | None = None,
        description: str | None = None,
        payment_method: str = "CASH",
        reference_number: str | None = None,
        period_start: date | None = None,
        period_end: date | None = None,
        export_format: str = "excel",
        user_id: UUID | None = None,
        correlation_id: str | None = None,
    ):
        super().__init__(
            command_type="UMKMWorkflowCommand", user_id=user_id, correlation_id=correlation_id
        )
        self.legal_entity_id = legal_entity_id
        self.action = action
        self.transaction_date = transaction_date
        self.amount = amount
        self.category = category
        self.description = description
        self.payment_method = payment_method
        self.reference_number = reference_number
        self.period_start = period_start
        self.period_end = period_end
        self.export_format = export_format

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data.update(
            {
                "legal_entity_id": str(self.legal_entity_id),
                "action": self.action,
                "transaction_date": (
                    self.transaction_date.isoformat() if self.transaction_date else None
                ),
                "amount": str(self.amount) if self.amount is not None else None,
                "category": self.category,
                "description": self.description,
                "payment_method": self.payment_method,
                "reference_number": self.reference_number,
                "period_start": self.period_start.isoformat() if self.period_start else None,
                "period_end": self.period_end.isoformat() if self.period_end else None,
                "export_format": self.export_format,
            }
        )
        return data


class UMKMWorkflowResult:
    def __init__(
        self,
        action: str,
        transaction_id: UUID | None,
        report_data: dict[str, Any] | None,
        file_path: str | None,
        message: str,
    ):
        self.action = action
        self.transaction_id = transaction_id
        self.report_data = report_data
        self.file_path = file_path
        self.message = message


class UMKMWorkflow:
    """
    Workflow sederhana untuk UMKM.
    """

    def __init__(
        self,
        umkm_service: UMKMService,
        journal_service: JournalService,
        tax_service: TaxService,
        sealed_gate: SealedGate | None = None,
    ):
        self._umkm_service = umkm_service
        self._journal_service = journal_service
        self._tax_service = tax_service
        self._sealed_gate = sealed_gate
        self._stats = {"executed": 0, "succeeded": 0, "failed": 0}
        self._audit_trail: list[dict[str, Any]] = []

    # ==================== AUTHORITY CHECK (SOD) ====================

    def _check_authority(self, user_id: UUID | None, permission: str) -> None:
        if user_id is None:
            logger.debug(f"System action for permission '{permission}' (no user_id)")
            return
        logger.debug(f"Authority check: user {user_id} permission '{permission}' passed (placeholder)")

    # ==================== AUDIT TRAIL ====================

    def _record_audit(self, action: str, details: dict[str, Any] | None = None) -> None:
        entry = {
            "timestamp": datetime.now(UTC).isoformat(),
            "service": "UMKMWorkflow",
            "action": action,
            "details": details or {},
        }
        self._audit_trail.append(entry)
        logger.info(f"AUDIT: {action} - {details}")

    @audit
    async def execute(self, command: UMKMWorkflowCommand) -> CommandResult:
        self._check_authority(command.user_id, "umkm_workflow_execute")
        self._stats["executed"] += 1

        try:
            if command.action == "RECORD_TRANSACTION":
                result = await self._record_transaction(command)
            elif command.action == "GENERATE_REPORT":
                result = await self._generate_report(command)
            elif command.action == "CALCULATE_TAX":
                result = await self._calculate_tax(command)
            else:
                raise ValueError(f"Unknown action: {command.action}")

            self._stats["succeeded"] += 1
            self._record_audit("umkm_workflow_execute", {
                "action": command.action,
                "user_id": str(command.user_id) if command.user_id else None,
            })

            return CommandResult.success(
                command_id=command.command_id,
                data={
                    "action": result.action,
                    "transaction_id": str(result.transaction_id) if result.transaction_id else None,
                    "file_path": result.file_path,
                    "message": result.message,
                },
            )

        except Exception as e:
            self._stats["failed"] += 1
            logger.exception(f"UMKM workflow failed: {e}")
            return CommandResult.failure(
                command_id=command.command_id, error=str(e), error_code="UMKM_WORKFLOW_ERROR"
            )

    async def _record_transaction(self, command: UMKMWorkflowCommand) -> UMKMWorkflowResult:
        if not command.transaction_date or not command.amount or not command.category:
            raise ValueError("Transaction date, amount, and category required")

        category_enum = None
        try:
            category_enum = TransactionCategory(command.category)
        except ValueError:
            raise ValueError(f"Invalid category: {command.category}")

        is_income = category_enum.value.startswith("INCOME")

        # BUG FIX: record_transaction() menerima satu objek TransactionRequest,
        # bukan kwargs datar - panggilan lama selalu TypeError.
        from application.service_layer.service_umkm import TransactionRequest

        transaction = await self._umkm_service.record_transaction(
            request=TransactionRequest(
                legal_entity_id=command.legal_entity_id,
                transaction_date=command.transaction_date,
                amount=command.amount,
                transaction_type="INCOME" if is_income else "EXPENSE",
                category=command.category,
                description=command.description or "",
                payment_method=command.payment_method,
                reference_number=command.reference_number,
            ),
            user_id=command.user_id,
            correlation_id=command.correlation_id,
        )

        # BUG FIX: create_simple_journal() tidak pernah ada di UMKMService.
        # record_transaction() di atas SUDAH menyimpan transaksi sepenuhnya
        # (lihat service_umkm.py: langsung save_transaction()+commit()) -
        # tidak ada langkah "buat jurnal terpisah" lain yang genuin diperlukan
        # untuk model akuntansi UMKM sederhana ini (beda dengan
        # create_journal_entry() yang merupakan fitur buku besar sederhana
        # yang terpisah, bukan lanjutan dari record_transaction).

        return UMKMWorkflowResult(
            action="RECORD_TRANSACTION",
            transaction_id=transaction.id,
            report_data=None,
            file_path=None,
            message=f"Transaction recorded: {command.category} of {command.amount}",
        )

    async def _generate_report(self, command: UMKMWorkflowCommand) -> UMKMWorkflowResult:
        if not command.period_start or not command.period_end:
            today = date.today()
            command.period_start = date(today.year, today.month, 1)
            if today.month == 12:
                command.period_end = date(today.year + 1, 1, 1) - timedelta(days=1)
            else:
                command.period_end = date(today.year, today.month + 1, 1) - timedelta(days=1)

        # BUG FIX: get_total_income()/get_total_expense()/list_transactions()
        # tidak pernah ada di UMKMService. Method aslinya adalah
        # get_simple_income_statement() (mengembalikan total_income DAN
        # total_expense sekaligus) dan get_transactions().
        income_statement = await self._umkm_service.get_simple_income_statement(
            command.legal_entity_id, command.period_start, command.period_end
        )
        income_total = income_statement.total_income
        expense_total = income_statement.total_expense
        net_profit = income_statement.net_profit

        transactions = await self._umkm_service.get_transactions(
            command.legal_entity_id, command.period_start, command.period_end
        )

        report_data = {
            "period_start": command.period_start.isoformat(),
            "period_end": command.period_end.isoformat(),
            "total_income": income_total,
            "total_expense": expense_total,
            "net_profit": net_profit,
            "transactions": [
                {
                    "date": t.transaction_date.isoformat(),
                    "type": t.transaction_type,
                    "category": t.category,
                    "amount": t.amount,
                    "description": t.description,
                }
                for t in transactions
            ],
        }

        file_path = None
        if command.export_format == "excel":
            file_path = await self._export_to_excel(report_data, command)
        elif command.export_format == "csv":
            file_path = await self._export_to_csv(report_data, command)

        return UMKMWorkflowResult(
            action="GENERATE_REPORT",
            transaction_id=None,
            report_data=report_data,
            file_path=file_path,
            message=f"Report generated for {command.period_start} to {command.period_end}",
        )

    async def _calculate_tax(self, command: UMKMWorkflowCommand) -> UMKMWorkflowResult:
        if not command.period_start or not command.period_end:
            today = date.today()
            command.period_start = date(today.year, today.month, 1)
            if today.month == 12:
                command.period_end = date(today.year + 1, 1, 1) - timedelta(days=1)
            else:
                command.period_end = date(today.year, today.month + 1, 1) - timedelta(days=1)

        # BUG FIX: get_total_income() dan get_tax_payments() tidak pernah ada
        # di UMKMService. Method resmi untuk kalkulasi pajak UMKM adalah
        # calculate_monthly_tax() (tarif 0.5% dari omzet, sama seperti yang
        # coba dihitung ulang secara manual di sini) - dipakai langsung
        # daripada duplikasi logika pajak. Tidak ada kapabilitas nyata untuk
        # melihat pajak yang SUDAH dibayar (tak ada get_tax_payments di
        # service manapun), jadi tax_paid dilaporkan 0 secara jujur alih-alih
        # mengarang data pembayaran yang tidak pernah ada.
        tax_summary = await self._umkm_service.calculate_monthly_tax(
            command.legal_entity_id, command.period_start.year, command.period_start.month
        )
        total_income = tax_summary.gross_revenue
        tax_due = tax_summary.tax_due
        total_paid = Decimal("0")
        tax_payable = max(tax_due - total_paid, Decimal("0"))

        tax_data = {
            "period": tax_summary.period,
            "gross_revenue": total_income,
            "tax_rate": tax_summary.tax_rate,
            "tax_due": tax_due,
            "tax_paid": total_paid,
            "tax_payable": tax_payable,
        }

        file_path = None
        if command.export_format == "excel":
            file_path = await self._export_tax_to_excel(tax_data, command)

        return UMKMWorkflowResult(
            action="CALCULATE_TAX",
            transaction_id=None,
            report_data=tax_data,
            file_path=file_path,
            message=f"Tax for {command.period_start.year}-{command.period_start.month:02d}: due {tax_due}, payable {tax_payable}",
        )

    # ========================================================================
    # PERBAIKAN: _export_to_excel menggunakan asyncio.to_thread
    # ========================================================================
    async def _export_to_excel(
        self, report_data: dict[str, Any], command: UMKMWorkflowCommand
    ) -> str:
        try:
            import openpyxl
            import openpyxl.utils
            from openpyxl.styles import Font, PatternFill

            def _create_excel_sync():
                wb = openpyxl.Workbook()
                ws = wb.active
                ws.title = "UMKM Report"

                ws["A1"] = "LAPORATAN UMKM"
                ws["A1"].font = Font(bold=True, size=14)
                ws.merge_cells("A1:F1")

                ws["A2"] = f"Periode: {report_data['period_start']} s/d {report_data['period_end']}"
                ws.merge_cells("A2:F2")

                ws["A4"] = "Ringkasan"
                ws["A4"].font = Font(bold=True)
                ws["A5"] = "Total Pendapatan"
                ws["B5"] = report_data["total_income"]
                ws["A6"] = "Total Beban"
                ws["B6"] = report_data["total_expense"]
                ws["A7"] = "Laba Bersih"
                ws["B7"] = report_data["net_profit"]

                ws["A9"] = "Detail Transaksi"
                ws["A9"].font = Font(bold=True)
                headers = ["Tanggal", "Jenis", "Kategori", "Jumlah", "Deskripsi"]
                for col, header in enumerate(headers, 1):
                    cell = ws.cell(row=10, column=col, value=header)
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")

                for row_idx, tx in enumerate(report_data["transactions"], start=11):
                    ws.cell(row=row_idx, column=1, value=tx["date"])
                    ws.cell(row=row_idx, column=2, value=tx["type"])
                    ws.cell(row=row_idx, column=3, value=tx["category"])
                    ws.cell(row=row_idx, column=4, value=tx["amount"])
                    ws.cell(row=row_idx, column=5, value=tx["description"])

                for col in range(1, 6):
                    ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 15

                file_path = (
                    f"/tmp/umkm_report_{command.legal_entity_id}_{datetime.utcnow().timestamp()}.xlsx"
                )
                wb.save(file_path)
                return file_path

            # Jalankan pembuatan Excel di thread pool (blocking)
            file_path = await asyncio.to_thread(_create_excel_sync)
            return file_path

        except ImportError:
            # Fallback ke CSV
            return await self._export_to_csv(report_data, command)

    # ========================================================================
    # PERBAIKAN: _export_to_csv menggunakan aiofiles
    # ========================================================================
    async def _export_to_csv(
        self, report_data: dict[str, Any], command: UMKMWorkflowCommand
    ) -> str:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["UMKM Report"])
        writer.writerow([f"Period: {report_data['period_start']} to {report_data['period_end']}"])
        writer.writerow([])
        writer.writerow(["Summary"])
        writer.writerow(["Total Income", str(report_data["total_income"])])
        writer.writerow(["Total Expense", str(report_data["total_expense"])])
        writer.writerow(["Net Profit", str(report_data["net_profit"])])
        writer.writerow([])
        writer.writerow(["Transactions"])
        writer.writerow(["Date", "Type", "Category", "Amount", "Description"])
        for tx in report_data["transactions"]:
            writer.writerow(
                [tx["date"], tx["type"], tx["category"], str(tx["amount"]), tx["description"]]
            )

        file_path = (
            f"/tmp/umkm_report_{command.legal_entity_id}_{datetime.utcnow().timestamp()}.csv"
        )

        # Tulis file secara async
        async with aiofiles.open(file_path, "w") as f:
            await f.write(output.getvalue())

        return file_path

    # ========================================================================
    # PERBAIKAN: _export_tax_to_excel menggunakan aiofiles
    # ========================================================================
    async def _export_tax_to_excel(
        self, tax_data: dict[str, Any], command: UMKMWorkflowCommand
    ) -> str:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["UMKM Tax Report"])
        writer.writerow([f"Period: {tax_data['period']}"])
        writer.writerow([])
        writer.writerow(["Gross Revenue", str(tax_data["gross_revenue"])])
        writer.writerow(["Tax Rate (%)", str(tax_data["tax_rate"])])
        writer.writerow(["Tax Due", str(tax_data["tax_due"])])
        writer.writerow(["Tax Paid", str(tax_data["tax_paid"])])
        writer.writerow(["Tax Payable", str(tax_data["tax_payable"])])

        file_path = f"/tmp/umkm_tax_{command.legal_entity_id}_{tax_data['period']}.csv"

        # Tulis file secara async
        async with aiofiles.open(file_path, "w") as f:
            await f.write(output.getvalue())

        return file_path

    def get_stats(self) -> dict[str, int]:
        return self._stats

    def get_audit_trail(self) -> list[dict[str, Any]]:
        return self._audit_trail.copy()


# ============================================================================
# Factory function
# ============================================================================


def create_umkm_workflow(
    umkm_service: UMKMService,
    journal_service: JournalService,
    tax_service: TaxService,
    sealed_gate: SealedGate | None = None,
) -> UMKMWorkflow:
    return UMKMWorkflow(
        umkm_service=umkm_service,
        journal_service=journal_service,
        tax_service=tax_service,
        sealed_gate=sealed_gate,
    )


__all__ = [
    "TransactionCategory",
    "UMKMWorkflow",
    "UMKMWorkflowCommand",
    "UMKMWorkflowResult",
    "create_umkm_workflow",
]
