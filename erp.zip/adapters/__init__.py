from __future__ import annotations

"""
Package: adapters
"""

__version__ = "1.0.0"

__all__ = ["__version__"]
