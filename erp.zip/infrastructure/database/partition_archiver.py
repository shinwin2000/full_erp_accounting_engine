#!/usr/bin/env python3
"""
Module: partition_archiver.py
Layer: Infrastructure (Database)
Responsibility: Mengarsipkan partisi lama ke cold storage (S3/Glacier) untuk
               mengurangi ukuran database aktif sambil tetap mempertahankan
               data untuk compliance. Mendukung detach partisi, kompresi,
               upload ke cold storage, dan kemampuan restore kembali.
Dependencies:
- asyncpg, asyncio, logging, subprocess
- infrastructure.database.session_factory_sqlalchemy (get_session_factory)
- infrastructure.file_storage.glacier_cold_storage_adapter (optional)
- config.loader_yaml
- infrastructure.telemetry.structured_json_logging
Audit: Setiap arsip partisi dicatat. Restore partisi juga dicatat.
"""

from __future__ import annotations

import asyncio
import gzip
import json
import shutil
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import aiofiles  # type: ignore[import-untyped]
from sqlalchemy import DDL

# Internal dependencies
from config.loader_yaml import load_yaml_config
from infrastructure.database.session_factory_sqlalchemy import get_session_factory
from infrastructure.telemetry.alert_manager_router import trigger_alert
from infrastructure.telemetry.structured_json_logging import get_logger

# Optional file storage
try:
    from infrastructure.file_storage.glacier_cold_storage_adapter import (
        get_glacier_cold_storage_adapter,
    )
    from infrastructure.file_storage.s3_adapter import get_s3_storage_adapter

    FILE_STORAGE_AVAILABLE = True
except ImportError:
    FILE_STORAGE_AVAILABLE = False

logger = get_logger(__name__)

# ============================================================================
# CONSTANTS
# ============================================================================

DEFAULT_ARCHIVE_CONFIG: dict[str, Any] = {
    "enabled": True,
    "archive_after_days": 730,  # Archive partitions older than 2 years
    "archive_storage": "glacier",  # glacier, s3, local
    "archive_bucket": "erp-archive",
    "archive_prefix": "partitions/",
    "compress": True,
    "retain_local_backup_days": 7,
    "tables": [
        {
            "name": "ledger_entry",
            "partition_column": "posting_date",
            "archive_after_days": 730,
            "enabled": True,
        },
        {
            "name": "journal_line",
            "partition_column": "created_at",
            "archive_after_days": 365,
            "enabled": True,
        },
        {
            "name": "event_store",
            "partition_column": "timestamp",
            "archive_after_days": 3650,
            "enabled": True,
        },
    ],
}

# ============================================================================
# EXCEPTIONS
# ============================================================================


class PartitionArchiverError(Exception):
    """Base exception untuk partition archiver."""

    pass


class ArchiveCreateError(PartitionArchiverError):
    """Error saat membuat arsip."""

    pass


class ArchiveRestoreError(PartitionArchiverError):
    """Error saat restore arsip."""

    pass


# ============================================================================
# PARTITION ARCHIVER
# ============================================================================


class PartitionArchiver:
    """
    Archiver untuk partisi database.

    Fitur:
    - Detach partisi yang sudah tua
    - Ekspor data partisi ke file (pg_dump)
    - Kompresi file
    - Upload ke cold storage (S3/Glacier)
    - Restore partisi dari arsip
    - Metadata tracking untuk arsip
    """

    def __init__(self, config_path: str = "config_files/database_config.yaml") -> None:
        self.config: dict[str, Any] = self._load_config(config_path)
        self._archive_tables: list[dict[str, Any]] = self.config.get("tables", [])
        self._enabled: bool = self.config.get("enabled", True)
        self._archive_storage: str = self.config.get("archive_storage", "glacier")
        self._archive_bucket: str = self.config.get("archive_bucket", "erp-archive")
        self._archive_prefix: str = self.config.get("archive_prefix", "partitions/")
        self._compress: bool = self.config.get("compress", True)
        self._archive_metadata: dict[str, dict[str, Any]] = {}

    def _load_config(self, config_path: str) -> dict[str, Any]:
        try:
            config = load_yaml_config(config_path)
            archive_config = config.get("partition_archive", {})
            result: dict[str, Any] = DEFAULT_ARCHIVE_CONFIG.copy()
            result.update(archive_config)
            return result
        except Exception:
            return DEFAULT_ARCHIVE_CONFIG.copy()

    async def _get_db_connection_info(self) -> dict[str, Any]:
        """Get database connection info from config."""
        from config.loader_yaml import load_yaml_config

        config = load_yaml_config("config_files/database_config.yaml")
        db_config = config.get("database", {})
        return {
            "host": db_config.get("host", "localhost"),
            "port": db_config.get("port", 5432),
            "database": db_config.get("database", "erp_db"),
            "user": db_config.get("user", "postgres"),
            "password": db_config.get("password"),
        }

    async def _get_old_partitions(self, table_config: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Get list of partitions older than archive_after_days.
        """
        table_name = table_config["name"]
        archive_days = table_config.get(
            "archive_after_days", self.config.get("archive_after_days", 730)
        )
        cutoff_date = datetime.now(UTC) - timedelta(days=archive_days)

        session_factory = await get_session_factory()
        # get_session() adalah coroutine; await dulu untuk mendapatkan AsyncSession
        db_session = await session_factory.get_session()
        async with db_session as session:
            query = """
            SELECT
                inhrelid::regclass::text as partition_name,
                pg_get_expr(c.relpartbound, inhrelid) as partition_range
            FROM pg_inherits
            JOIN pg_class c ON inhrelid = c.oid
            WHERE inhparent = :parent::regclass
            """
            result = await session.execute(query, {"parent": table_name})
            partitions: list[dict[str, Any]] = []
            for row in result:
                part_name = row[0]
                part_range = row[1]
                try:
                    if "_" in part_name:
                        part_date_str = part_name.split("_")[-1]
                        if len(part_date_str) == 7:
                            part_date = datetime.strptime(part_date_str, "%Y_%m")
                        else:
                            part_date = datetime.strptime(part_date_str, "%Y_%m_%d")
                        if part_date < cutoff_date:
                            partitions.append(
                                {"name": part_name, "range": part_range, "date": part_date}
                            )
                except (ValueError, IndexError):
                    continue
            return partitions

    async def _detach_partition(self, table_name: str, partition_name: str) -> None:
        session_factory = await get_session_factory()
        db_session = await session_factory.get_session()
        async with db_session as session, session.begin():
            stmt = DDL("ALTER TABLE %(table)s DETACH PARTITION %(partition)s")
            await session.execute(stmt, {"table": table_name, "partition": partition_name})
            logger.info(f"Detached partition {partition_name} from {table_name}")

    async def _export_partition(self, partition_name: str, output_path: Path) -> None:
        db_info = await self._get_db_connection_info()
        cmd = [
            "pg_dump",
            "-h",
            db_info["host"],
            "-p",
            str(db_info["port"]),
            "-U",
            db_info["user"],
            "-d",
            db_info["database"],
            "-t",
            partition_name,
            "-F",
            "c",
            "-f",
            str(output_path),
            "--no-owner",
            "--no-privileges",
        ]

        env: dict[str, str] | None = None
        if db_info.get("password"):
            env = {"PGPASSWORD": db_info["password"]}

        process = await asyncio.create_subprocess_exec(
            *cmd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()

        if process.returncode != 0:
            raise ArchiveCreateError(f"pg_dump failed: {stderr.decode()}")

        logger.info(f"Exported partition {partition_name} to {output_path}")

    # ========================================================================
    # PERBAIKAN: _compress_file menggunakan aiofiles + asyncio.to_thread
    # ========================================================================

    async def _compress_file(self, file_path: Path) -> Path:
        """
        Compress file using gzip.
        """
        compressed_path = file_path.with_suffix(file_path.suffix + ".gz")

        # Baca file secara async
        async with aiofiles.open(file_path, "rb") as f:
            file_content = await f.read()

        # Kompresi di thread pool
        def _compress_sync(data: bytes) -> bytes:
            return gzip.compress(data, compresslevel=6)

        compressed_data = await asyncio.to_thread(_compress_sync, file_content)

        # Tulis file secara async
        async with aiofiles.open(compressed_path, "wb") as f:
            await f.write(compressed_data)

        logger.info(f"Compressed {file_path} to {compressed_path}")
        return compressed_path

    # ========================================================================
    # PERBAIKAN: _upload_to_storage — pisahkan variabel per cabang agar mypy
    # tidak menyimpulkan tipe dari cabang pertama (Glacier) lalu menolak
    # assignment berikutnya (S3). ``uri`` dianotasi ``str`` di awal karena
    # semua cabang pasti meng-assign-nya.
    # ========================================================================

    async def _upload_to_storage(self, file_path: Path, archive_key: str) -> str:
        if not FILE_STORAGE_AVAILABLE:
            logger.warning("File storage not available, keeping local copy")
            return f"local://{file_path}"

        async with aiofiles.open(file_path, "rb") as f:
            file_content = await f.read()

        uri: str
        if self._archive_storage == "glacier":
            glacier_storage = await get_glacier_cold_storage_adapter()
            uri = await glacier_storage.upload(
                file_content=file_content,
                file_name=file_path.name,
                metadata={"archive_key": archive_key},
            )
        elif self._archive_storage == "s3":
            s3_storage = await get_s3_storage_adapter()
            uri = await s3_storage.upload(
                file_content=file_content,
                file_name=file_path.name,
                bucket=self._archive_bucket,
            )
        else:

            def _local_copy() -> str:
                archive_dir = Path("/var/archives")
                archive_dir.mkdir(parents=True, exist_ok=True)
                dest = archive_dir / file_path.name
                shutil.copy(file_path, dest)
                return f"local://{dest}"

            uri = await asyncio.to_thread(_local_copy)

        logger.info(f"Uploaded archive to {uri}")
        return uri

    async def _drop_partition(self, partition_name: str) -> None:
        session_factory = await get_session_factory()
        db_session = await session_factory.get_session()
        async with db_session as session, session.begin():
            await session.execute(DDL(f"DROP TABLE IF EXISTS {partition_name}"))
            logger.info(f"Dropped partition {partition_name}")

    # ========================================================================
    # Helper untuk temporary file dan unlink di thread pool
    # ========================================================================

    async def _create_temp_file(self, suffix: str = ".dump") -> Path:
        def _create() -> Path:
            _fd, path = tempfile.mkstemp(suffix=suffix)
            return Path(path)

        return await asyncio.to_thread(_create)

    async def _delete_file(self, path: Path, ignore_missing: bool = True) -> None:
        def _delete() -> None:
            if ignore_missing:
                path.unlink(missing_ok=True)
            else:
                path.unlink()

        await asyncio.to_thread(_delete)

    # ========================================================================
    # Archive partition
    # ========================================================================

    async def archive_partition(
        self, table_config: dict[str, Any], partition: dict[str, Any]
    ) -> dict[str, Any]:
        table_name = table_config["name"]
        partition_name = partition["name"]
        archive_key = f"{self._archive_prefix}{table_name}/{partition_name}.dump"

        result: dict[str, Any] = {
            "partition": partition_name,
            "table": table_name,
            "status": "pending",
            "archive_uri": None,
            "error": None,
        }

        try:
            await self._detach_partition(table_name, partition_name)

            dump_path = await self._create_temp_file(suffix=".dump")
            await self._export_partition(partition_name, dump_path)

            file_to_upload = dump_path
            if self._compress:
                file_to_upload = await self._compress_file(dump_path)
                await self._delete_file(dump_path, ignore_missing=True)

            uri = await self._upload_to_storage(file_to_upload, archive_key)
            result["archive_uri"] = uri

            await self._drop_partition(partition_name)
            await self._delete_file(file_to_upload, ignore_missing=True)

            result["status"] = "archived"
            result["archived_at"] = datetime.now(UTC).isoformat()
            logger.info(f"Successfully archived partition {partition_name}")

            self._archive_metadata[archive_key] = result

        except Exception as e:
            result["status"] = "failed"
            result["error"] = str(e)
            logger.error(f"Failed to archive partition {partition_name}: {e}")
            await trigger_alert(
                title="Partition Archive Failed",
                message=f"Failed to archive partition {partition_name}: {e}",
                severity="warning",
                source="PartitionArchiver",
            )

        return result

    async def archive_old_partitions(self, dry_run: bool = False) -> dict[str, Any]:
        if not self._enabled:
            logger.info("Partition archiving is disabled")
            return {"enabled": False}

        # Anotasi eksplisit agar mypy tahu tipe nested-nya
        results: dict[str, dict[str, Any]] = {}
        for table_config in self._archive_tables:
            if not table_config.get("enabled", True):
                continue

            table_name = table_config["name"]
            partitions = await self._get_old_partitions(table_config)
            table_result: dict[str, Any] = {
                "partitions_found": len(partitions),
                "archived": [],
                "failed": [],
            }
            results[table_name] = table_result

            for partition in partitions:
                if dry_run:
                    table_result["archived"].append(
                        {"partition": partition["name"], "dry_run": True}
                    )
                else:
                    archive_result = await self.archive_partition(table_config, partition)
                    if archive_result["status"] == "archived":
                        table_result["archived"].append(archive_result)
                    else:
                        table_result["failed"].append(archive_result)

        return results

    # ========================================================================
    # PERBAIKAN: restore_partition — pisahkan variabel storage per cabang
    # agar mypy tidak menyimpulkan tipe dari cabang pertama. ``content``
    # dianotasi ``Any`` karena ``download()`` bisa mengembalikan ``bytes``
    # atau ``BinaryIO`` tergantung adapter.
    # ========================================================================

    async def restore_partition(self, archive_key: str, target_table: str) -> bool:
        try:
            content: Any = None
            if self._archive_storage == "glacier":
                glacier_storage = await get_glacier_cold_storage_adapter()
                content = await glacier_storage.download(archive_key)
            elif self._archive_storage == "s3":
                s3_storage = await get_s3_storage_adapter()
                content = await s3_storage.download(archive_key)
            else:
                local_path = Path(archive_key.replace("local://", ""))
                async with aiofiles.open(local_path, "rb") as f:
                    content = await f.read()

            if content is None:
                raise ArchiveRestoreError("Failed to download archive content")

            if archive_key.endswith(".gz"):

                def _decompress_sync(data: bytes) -> bytes:
                    return gzip.decompress(data)

                content = await asyncio.to_thread(_decompress_sync, content)

            dump_path = await self._create_temp_file(suffix=".dump")
            async with aiofiles.open(dump_path, "wb") as f:
                await f.write(content)

            db_info = await self._get_db_connection_info()
            cmd = [
                "pg_restore",
                "-h",
                db_info["host"],
                "-p",
                str(db_info["port"]),
                "-U",
                db_info["user"],
                "-d",
                db_info["database"],
                "--clean",
                "--if-exists",
                "--no-owner",
                "--no-privileges",
                str(dump_path),
            ]

            env: dict[str, str] | None = None
            if db_info.get("password"):
                env = {"PGPASSWORD": db_info["password"]}

            process = await asyncio.create_subprocess_exec(
                *cmd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()

            if process.returncode != 0:
                raise ArchiveRestoreError(f"pg_restore failed: {stderr.decode()}")

            await self._delete_file(dump_path, ignore_missing=True)

            logger.info(f"Successfully restored partition from {archive_key}")
            return True

        except Exception as e:
            logger.error(f"Failed to restore partition: {e}")
            await trigger_alert(
                title="Partition Restore Failed",
                message=f"Failed to restore partition from {archive_key}: {e}",
                severity="error",
                source="PartitionArchiver",
            )
            return False

    async def list_archives(self, table_name: str | None = None) -> list[dict[str, Any]]:
        archives: list[dict[str, Any]] = []
        for _key, metadata in self._archive_metadata.items():
            if table_name and metadata.get("table") != table_name:
                continue
            archives.append(metadata)
        return archives

    async def get_archive_stats(self) -> dict[str, Any]:
        total_archived = sum(
            1 for m in self._archive_metadata.values() if m.get("status") == "archived"
        )
        return {
            "total_archives": len(self._archive_metadata),
            "successful_archives": total_archived,
            "failed_archives": len(self._archive_metadata) - total_archived,
            "tables_configured": len(self._archive_tables),
            "archive_storage": self._archive_storage,
            "archive_bucket": self._archive_bucket,
        }


# ============================================================================
# SINGLETON INSTANCE
# ============================================================================

_partition_archiver: PartitionArchiver | None = None


async def get_partition_archiver() -> PartitionArchiver:
    global _partition_archiver
    if _partition_archiver is None:
        _partition_archiver = PartitionArchiver()
    return _partition_archiver


# ============================================================================
# CLI COMMAND
# ============================================================================


def cli() -> None:
    import argparse
    import asyncio

    parser = argparse.ArgumentParser(description="Partition archiver")
    parser.add_argument(
        "command", choices=["archive", "list", "stats", "restore"], help="Archive command"
    )
    parser.add_argument("--table", "-t", help="Table name")
    parser.add_argument("--dry-run", action="store_true", help="Dry run")
    parser.add_argument("--archive-key", help="Archive key for restore")

    args = parser.parse_args()

    async def run() -> None:
        archiver = await get_partition_archiver()

        if args.command == "archive":
            result = await archiver.archive_old_partitions(dry_run=args.dry_run)
            print(json.dumps(result, indent=2, default=str))
        elif args.command == "list":
            archives = await archiver.list_archives(args.table)
            for a in archives:
                print(f"{a['partition']}: {a['status']} - {a.get('archive_uri', 'N/A')}")
        elif args.command == "stats":
            stats = await archiver.get_archive_stats()
            print(json.dumps(stats, indent=2))
        elif args.command == "restore":
            if not args.archive_key:
                print("Error: --archive-key required for restore")
                return
            success = await archiver.restore_partition(args.archive_key, args.table or "unknown")
            print(f"Restore {'successful' if success else 'failed'}")

    asyncio.run(run())


# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    "ArchiveCreateError",
    "ArchiveRestoreError",
    "PartitionArchiver",
    "PartitionArchiverError",
    "get_partition_archiver",
]

if __name__ == "__main__":
    cli()
    