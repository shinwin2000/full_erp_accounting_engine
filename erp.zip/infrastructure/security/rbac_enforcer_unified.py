#!/usr/bin/env python3
"""
Module: rbac_enforcer_unified.py
Layer: Infrastructure (Security)
Responsibility: Enforcer untuk Role-Based Access Control (RBAC) yang terintegrasi
               dengan kernel guards dan authority matrix.
Dependencies:
- asyncio, logging, ast
- domain.iam.user_entity (UserStatus)
- infrastructure.security.authority_matrix (AuthorityMatrix)
- infrastructure.caching.redis_manager (RedisManager)
- ports.primary.iam_user_repository_port (IAMUserRepositoryPort)
- app.container (IoCContainer)
- infrastructure.telemetry.alert_manager_router (trigger_alert)
- infrastructure.telemetry.structured_json_logging
Audit: Setiap keputusan akses (allow/deny) dicatat untuk audit trail.
       Pelanggaran akses berulang memicu alert security.
"""

from __future__ import annotations

import ast  # <-- tambahan untuk safe eval
import asyncio
import json
import logging
from typing import Any
from uuid import UUID

# Internal dependencies
from domain.iam.user_entity import UserStatus
from infrastructure.caching.redis_manager import RedisManager, get_redis_manager
from infrastructure.security.authority_matrix import AuthorityMatrix
from infrastructure.telemetry.alert_manager_router import trigger_alert
from ports.primary.iam_user_repository_port import IAMUserRepositoryPort

logger = logging.getLogger(__name__)

# ============================================================================
# CONSTANTS
# ============================================================================

REDIS_PERMISSION_CACHE_PREFIX = "rbac:user_perms:"
PERMISSION_CACHE_TTL_SECONDS = 300  # 5 minutes

# Special permission for superuser
SUPERUSER_PERMISSION = "*:*"

# ============================================================================
# EXCEPTIONS
# ============================================================================

class RBACEnforcerError(Exception):
    """Base exception untuk RBAC enforcer."""
    pass

class PermissionDeniedError(RBACEnforcerError):
    """User tidak memiliki permission yang diperlukan."""

    def __init__(self, user_id: UUID, resource: str, action: str, required_permission: str):
        self.user_id = user_id
        self.resource = resource
        self.action = action
        self.required_permission = required_permission
        super().__init__(f"Permission denied for user {user_id}: {required_permission}")

class UserNotFoundError(RBACEnforcerError):
    """User tidak ditemukan."""
    pass

# ============================================================================
# RBAC ENFORCER
# ============================================================================

class RBACEnforcer:
    """
    Enforcer untuk Role-Based Access Control.

    Method Standards (ERP):
    - check_permission() - Memeriksa permission
    - enforce() - Menerapkan permission (raise jika tidak diizinkan)
    - check_permissions_batch() - Batch permission check
    - get_user_permissions() - Mendapatkan semua permission user
    - has_any_permission() - Cek apakah user memiliki salah satu permission
    - has_all_permissions() - Cek apakah user memiliki semua permission
    - invalidate_cache() - Invalidasi cache permission
    - clear_cache() - Membersihkan semua cache
    - get_stats() - Mendapatkan statistik enforcer
    - reset() - Reset enforcer state
    """

    def __init__(self, authority_matrix: AuthorityMatrix | None = None):
        self._authority_matrix = authority_matrix or AuthorityMatrix()
        self._redis_manager: RedisManager | None = None
        self._user_repo: IAMUserRepositoryPort | None = None
        self._permission_cache: dict[str, set[str]] = {}  # user_id -> set of permissions
        self._access_denied_counter: dict[str, int] = {}
        self._logger = logging.getLogger(f"{__name__}.RBACEnforcer")

    async def _get_redis(self) -> RedisManager:
        if self._redis_manager is None:
            self._redis_manager = await get_redis_manager()
        return self._redis_manager

    async def _get_user_repo(self) -> IAMUserRepositoryPort:
        if self._user_repo is None:
            # Dynamic import to avoid architecture layer violation (P08)
            get_container = __import__('bootstrap.dependency_container.ioc_container', fromlist=['get_container']).get_container
            container = get_container()
            self._user_repo = await container.resolve_async(IAMUserRepositoryPort)
        return self._user_repo

    def _get_cache_key(self, user_id: UUID) -> str:
        """Get Redis cache key for user permissions."""
        return f"{REDIS_PERMISSION_CACHE_PREFIX}{user_id}"

    async def _get_user_permissions(
        self, user_id: UUID, legal_entity_id: UUID | None = None
    ) -> set[str]:
        """
        Get all permissions for a user (including inherited from roles).
        """
        # Check in-memory cache first
        user_id_str = str(user_id)
        if user_id_str in self._permission_cache:
            return self._permission_cache[user_id_str]

        # Check Redis cache
        redis = await self._get_redis()
        cache_key = self._get_cache_key(user_id)
        cached = await redis.get(cache_key)

        if cached is not None:
            try:
                # Handle different possible types returned from Redis
                if isinstance(cached, bytes):
                    cached = cached.decode('utf-8')
                if isinstance(cached, str):
                    # Try JSON parse
                    try:
                        permissions = set(json.loads(cached))
                    except json.JSONDecodeError:
                        # Maybe it's a string representation of a list, try ast.literal_eval
                        try:
                            permissions = set(ast.literal_eval(cached))
                        except (ValueError, SyntaxError):
                            # If it's a plain string, treat as single permission
                            permissions = {cached} if cached else set()
                elif isinstance(cached, list):
                    permissions = set(cached)
                elif isinstance(cached, set):
                    permissions = cached
                else:
                    # Fallback: convert to string and try to parse
                    permissions = set(str(cached).split(',')) if cached else set()
                self._permission_cache[user_id_str] = permissions
                return permissions
            except Exception as e:
                self._logger.warning(f"Error reading cache for {cache_key}: {e}")
                # Fall through to load from DB

        # Load user from repository
        user_repo = await self._get_user_repo()
        from infrastructure.database.session_factory_sqlalchemy import get_async_session_factory
        _session_maker = await get_async_session_factory()
        _db_session = _session_maker()
        user_repo.set_session(_db_session)
        try:
            user = await user_repo.get_by_id(user_id)

            if not user:
                raise UserNotFoundError(f"User {user_id} not found")

            # Check if user is active
            if user.status != UserStatus.ACTIVE:
                self._logger.warning(f"User {user_id} is not active (status: {user.status})")
                return set()

            # Collect all permissions from user's roles
            permissions = set()

            if getattr(user, "is_superuser", False):
                permissions.add(SUPERUSER_PERMISSION)
            else:
                for role in await user_repo.get_user_roles(user_id):
                    role_id = getattr(role, "role_id", None) or getattr(role, "id", None)
                    role_permissions = await user_repo.get_role_permissions(role_id)
                    for perm in role_permissions:
                        if (
                            legal_entity_id is None
                            or perm.legal_entity_id is None
                            or perm.legal_entity_id == legal_entity_id
                        ):
                            permissions.add(perm.permission_key)

            # Cache permissions as JSON string
            await redis.set(cache_key, json.dumps(list(permissions)), PERMISSION_CACHE_TTL_SECONDS)
            self._permission_cache[user_id_str] = permissions

            self._logger.debug(f"Cached {len(permissions)} permissions for user {user_id}")
            return permissions
        finally:
            await _db_session.close()

    async def check_permission(
        self, user_id: UUID, resource: str, action: str, legal_entity_id: UUID | None = None
    ) -> bool:
        """
        Check if user has permission for a specific resource and action.

        Args:
            user_id: User ID
            resource: Resource name (e.g., "journal", "ledger", "ar_invoice")
            action: Action name (e.g., "create", "read", "update", "delete")
            legal_entity_id: Legal entity context (for multi-tenant)

        Returns:
            True if allowed, False otherwise
        """
        if not user_id:
            raise ValueError("user_id cannot be None")
        if not resource or not action:
            raise ValueError("resource and action cannot be empty")

        required_permission = f"{resource}:{action}"

        permissions = await self._get_user_permissions(user_id, legal_entity_id)

        # Superuser bypass
        if SUPERUSER_PERMISSION in permissions:
            return True

        # Check exact permission
        if required_permission in permissions:
            return True

        # Check wildcard permission (e.g., "journal:*")
        wildcard = f"{resource}:*"
        if wildcard in permissions:
            return True

        # Check authority matrix for additional rules
        if await self._authority_matrix.is_allowed(user_id, resource, action, legal_entity_id):
            return True

        # Record access denied for monitoring
        self._record_access_denied(user_id, required_permission)

        return False

    def _record_access_denied(self, user_id: UUID, permission: str) -> None:
        """
        Record access denied for monitoring and alerting.
        """
        key = f"{user_id}:{permission}"
        self._access_denied_counter[key] = self._access_denied_counter.get(key, 0) + 1

        # Alert if too many denials
        if self._access_denied_counter[key] >= 10:
            _task = asyncio.create_task(  # noqa: RUF006
                trigger_alert(
                    title="Multiple Permission Denials",
                    message=f"User {user_id} denied access to {permission} {self._access_denied_counter[key]} times",
                    severity="warning",
                    source="RBACEnforcer",
                )
            )
            # Reset counter after alert
            self._access_denied_counter[key] = 0

    async def enforce(
        self, user_id: UUID, resource: str, action: str, legal_entity_id: UUID | None = None
    ) -> None:
        """
        Enforce permission - raises exception if denied.

        Raises:
            PermissionDeniedError: If user does not have permission
        """
        if not await self.check_permission(user_id, resource, action, legal_entity_id):
            raise PermissionDeniedError(user_id, resource, action, f"{resource}:{action}")

    async def check_permissions_batch(
        self, user_id: UUID, checks: list[dict[str, str]], legal_entity_id: UUID | None = None
    ) -> dict[str, bool]:
        """
        Check multiple permissions in batch.

        Args:
            user_id: User ID
            checks: List of dict with keys "resource" and "action"
            legal_entity_id: Legal entity context

        Returns:
            Dict mapping permission string to boolean
        """
        if not user_id:
            raise ValueError("user_id cannot be None")
        if not checks:
            return {}

        permissions = await self._get_user_permissions(user_id, legal_entity_id)
        results = {}

        for check in checks:
            resource = check.get("resource")
            action = check.get("action")
            if not resource or not action:
                raise ValueError("Each check must have 'resource' and 'action' keys")
            perm = f"{resource}:{action}"

            if (
                SUPERUSER_PERMISSION in permissions
                or perm in permissions
                or f"{resource}:*" in permissions
            ):
                results[perm] = True
            else:
                results[perm] = await self._authority_matrix.is_allowed(
                    user_id, resource, action, legal_entity_id
                )

        return results

    async def get_user_permissions(
        self, user_id: UUID, legal_entity_id: UUID | None = None
    ) -> list[str]:
        """
        Get list of all permissions for a user.
        """
        permissions = await self._get_user_permissions(user_id, legal_entity_id)
        return list(permissions)

    async def has_any_permission(
        self, user_id: UUID, permissions: list[str], legal_entity_id: UUID | None = None
    ) -> bool:
        """
        Check if user has any of the listed permissions.
        """
        if not user_id:
            raise ValueError("user_id cannot be None")
        if not permissions:
            return False

        user_perms = await self._get_user_permissions(user_id, legal_entity_id)
        return any(p in user_perms for p in permissions)

    async def has_all_permissions(
        self, user_id: UUID, permissions: list[str], legal_entity_id: UUID | None = None
    ) -> bool:
        """
        Check if user has all of the listed permissions.
        """
        if not user_id:
            raise ValueError("user_id cannot be None")
        if not permissions:
            return True

        user_perms = await self._get_user_permissions(user_id, legal_entity_id)
        return all(p in user_perms for p in permissions)

    async def invalidate_cache(self, user_id: UUID) -> None:
        """
        Invalidate permission cache for a user (after role/permission changes).
        """
        if not user_id:
            raise ValueError("user_id cannot be None")

        # Clear in-memory cache
        user_id_str = str(user_id)
        if user_id_str in self._permission_cache:
            del self._permission_cache[user_id_str]

        # Clear Redis cache
        redis = await self._get_redis()
        cache_key = self._get_cache_key(user_id)
        await redis.delete(cache_key)

        self._logger.info(f"Permission cache invalidated for user {user_id}")

    async def clear_cache(self) -> None:
        """Clear entire permission cache."""
        self._permission_cache.clear()

        redis = await self._get_redis()
        pattern = f"{REDIS_PERMISSION_CACHE_PREFIX}*"
        keys = await redis.keys(pattern)
        if keys:
            await redis.delete(*keys)

        self._logger.info("Permission cache cleared")

    async def get_stats(self) -> dict[str, Any]:
        """
        Get enforcer statistics.
        """
        return {
            "cache_size": len(self._permission_cache),
            "access_denied_counts": dict(self._access_denied_counter),
            "superuser_enabled": bool(SUPERUSER_PERMISSION),
        }

    async def reset(self) -> None:
        """
        Reset enforcer state (clear cache and counters).
        """
        await self.clear_cache()
        self._access_denied_counter.clear()
        self._logger.info("RBAC enforcer reset")

# ============================================================================
# SINGLETON INSTANCE
# ============================================================================

_rbac_enforcer: RBACEnforcer | None = None

async def get_rbac_enforcer() -> RBACEnforcer:
    """Get singleton instance of RBACEnforcer."""
    global _rbac_enforcer
    if _rbac_enforcer is None:
        _rbac_enforcer = RBACEnforcer()
    return _rbac_enforcer

# ============================================================================
# DECORATOR
# ============================================================================

def require_permission(resource: str, action: str):
    """
    Decorator untuk memeriksa permission sebelum menjalankan fungsi.
    """

    def decorator(func):
        async def wrapper(user_id: UUID, *args, **kwargs):
            enforcer = await get_rbac_enforcer()
            await enforcer.enforce(user_id, resource, action)
            return await func(user_id, *args, **kwargs)

        return wrapper

    return decorator

# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    "PermissionDeniedError",
    "RBACEnforcer",
    "RBACEnforcerError",
    "UserNotFoundError",
    "get_rbac_enforcer",
    "require_permission",
]
