#!/usr/bin/env python3
"""
Module: journal_line_table.py
Layer: Infrastructure (Persistence ORM)
Responsibility: Mendefinisikan model SQLAlchemy untuk tabel journal_line.
"""

from __future__ import annotations

import uuid
from decimal import Decimal
from typing import TYPE_CHECKING, Any
from uuid import UUID

from sqlalchemy import (
    CheckConstraint,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    Integer,
    Numeric,
    String,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from infrastructure.persistence_orm.base_model import (
    Base,
    LegalEntityMixin,
    SoftDeleteMixin,
    TimestampMixin,
    VersionMixin,
)

if TYPE_CHECKING:
    from infrastructure.persistence_orm.account_table import AccountTable
    from infrastructure.persistence_orm.journal_header_table import JournalHeaderTable


class JournalLineTable(Base, TimestampMixin, SoftDeleteMixin, VersionMixin, LegalEntityMixin):
    # ``Base`` mendeklarasikan ``__tablename__`` sebagai ``Callable[[Base], str]``
    # (kemungkinan karena metaclass/factory untuk auto-generate nama tabel).
    # Subclass menimpanya dengan string literal — assignment yang secara tipe
    # tidak kompatibel, tapi sah secara runtime untuk SQLAlchemy declarative.
    __tablename__ = "journal_line"  # type: ignore[assignment]
    __table_args__ = (
        # PERBAIKAN: hapus prefix "public." untuk menghindari schema mismatch
        ForeignKeyConstraint(
            ["account_code", "legal_entity_id"],
            ["account.account_code", "account.legal_entity_id"],
            name="fk_journal_line_account",
        ),
        CheckConstraint("debit_amount >= 0", name="ck_journal_line_debit_nonneg"),
        CheckConstraint("credit_amount >= 0", name="ck_journal_line_credit_nonneg"),
        CheckConstraint("debit_amount > 0 OR credit_amount > 0", name="ck_journal_line_nonzero"),
        CheckConstraint("line_number >= 1", name="ck_journal_line_number"),
        Index("idx_journal_line_journal", "journal_id"),
        Index("idx_journal_line_account", "account_code"),
        Index("idx_journal_line_legal_entity", "legal_entity_id"),
        Index("idx_journal_line_cost_center", "cost_center"),
        {"extend_existing": True},
    )

    id: Mapped[UUID] = mapped_column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    journal_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True), ForeignKey("journal_header.id"), nullable=False
    )
    account_code: Mapped[str] = mapped_column(String(20), nullable=False)
    line_number: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    debit_amount: Mapped[Decimal] = mapped_column(Numeric(20, 2), nullable=False, default=0)
    credit_amount: Mapped[Decimal] = mapped_column(Numeric(20, 2), nullable=False, default=0)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="IDR")
    # fc_amount & booking_rate: nullable, diisi HANYA untuk baris jurnal
    # yang currency != functional currency entitas. fc_amount = nilai asli
    # dalam mata uang asing SEBELUM dikonversi; booking_rate = kurs yang
    # dipakai saat itu (fc_amount * booking_rate seharusnya == debit_amount
    # atau credit_amount, tergantung sisi). Tanpa keduanya, unrealized FX
    # gain/loss tidak bisa dihitung akurat - baris lama (sebelum kolom ini
    # ada) akan punya nilai None di sini dan otomatis dikecualikan dari
    # perhitungan gain/loss sampai dibukukan ulang.
    fc_amount: Mapped[Decimal | None] = mapped_column(Numeric(20, 4), nullable=True)
    booking_rate: Mapped[Decimal | None] = mapped_column(Numeric(20, 6), nullable=True)
    cost_center: Mapped[str | None] = mapped_column(String(20), nullable=True)
    department: Mapped[str | None] = mapped_column(String(20), nullable=True)
    account_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    # ------------------------------------------------------------------
    # SNAPSHOT KOLOM (point-in-time accounting)
    # ------------------------------------------------------------------
    # `account_name` di atas, plus dua kolom ini, adalah "potret" atribut
    # akun PERSIS SAAT baris jurnal ini dibuat — diisi otomatis oleh
    # SQLAlchemyJournalRepository._to_orm_lines(), BUKAN oleh caller.
    # Tujuannya: kalau suatu akun di COA diubah nama/tipe/saldo normalnya
    # di kemudian hari, laporan keuangan periode-periode LAMA tidak ikut
    # berubah (tetap merujuk ke kondisi akun saat transaksi itu terjadi).
    # Jangan pernah query field ini balik ke tabel `account` untuk data
    # historis — gunakan nilai yang tersimpan di sini.
    account_type_snapshot: Mapped[str | None] = mapped_column(String(20), nullable=True)
    normal_balance_snapshot: Mapped[str | None] = mapped_column(String(6), nullable=True)
    audit_metadata: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Relasi
    journal: Mapped[JournalHeaderTable] = relationship(
        "JournalHeaderTable",
        back_populates="lines",
        foreign_keys=[journal_id],
    )
    account: Mapped[AccountTable] = relationship(
        "AccountTable",
        back_populates="journal_lines",
        primaryjoin="and_(JournalLineTable.account_code == AccountTable.account_code, "
                    "JournalLineTable.legal_entity_id == AccountTable.legal_entity_id)",
        foreign_keys="[JournalLineTable.account_code, JournalLineTable.legal_entity_id]",
        viewonly=True,
    )

    @property
    def amount(self) -> Decimal:
        return self.debit_amount if self.debit_amount > 0 else self.credit_amount

    @property
    def is_debit(self) -> bool:
        return self.debit_amount > 0

    @property
    def is_credit(self) -> bool:
        return self.credit_amount > 0

    def validate(self) -> bool:
        return (self.debit_amount > 0) != (self.credit_amount > 0)

    def get_absolute_amount(self) -> Decimal:
        return self.amount

    def to_dict(self) -> dict[str, Any]:  # type: ignore[override]
        return {
            "id": str(self.id),
            "journal_id": str(self.journal_id),
            "account_code": self.account_code,
            "line_number": self.line_number,
            "description": self.description,
            "debit_amount": float(self.debit_amount),
            "credit_amount": float(self.credit_amount),
            "currency": self.currency,
            "fc_amount": float(self.fc_amount) if self.fc_amount is not None else None,
            "booking_rate": float(self.booking_rate) if self.booking_rate is not None else None,
            "cost_center": self.cost_center,
            "department": self.department,
            "account_name": self.account_name,
            "account_type_snapshot": self.account_type_snapshot,
            "normal_balance_snapshot": self.normal_balance_snapshot,
            "audit_metadata": self.audit_metadata,
            "legal_entity_id": str(self.legal_entity_id),
        }


__all__ = ["JournalLineTable"]
