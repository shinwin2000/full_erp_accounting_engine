#!/usr/bin/env python3
"""
Module: amortization_schedule_table.py
Layer: Infrastructure (Persistence ORM)
Responsibility: Model untuk jadwal amortisasi aset tidak berwujud.
"""

from __future__ import annotations

import enum
import uuid
from datetime import date
from decimal import Decimal
from typing import Any

from sqlalchemy import CheckConstraint, Date, Enum, ForeignKey, Index, Integer, Numeric, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from infrastructure.persistence_orm.base_model import Base, TimestampMixin


class AmortizationStatus(str, enum.Enum):
    PENDING = "PENDING"
    POSTED = "POSTED"
    SKIPPED = "SKIPPED"
    ADJUSTED = "ADJUSTED"


class AmortizationScheduleTable(Base, TimestampMixin):
    # ``Base`` mendeklarasikan ``__tablename__`` sebagai ``Callable[[Base], str]``
    # (kemungkinan karena metaclass/factory untuk auto-generate nama tabel).
    # Subclass menimpanya dengan string literal — assignment yang secara tipe
    # tidak kompatibel, tapi sah secara runtime untuk SQLAlchemy declarative.
    __tablename__ = "amortization_schedule"  # type: ignore[assignment]
    # Anotasi eksplisit ``tuple[Any, ...]`` karena tuple ini bercampur
    # ``CheckConstraint``, ``Index``, dan ``dict`` (argumen terakhir SQLAlchemy
    # declarative) — tanpa anotasi, mypy tidak bisa menginferensi tipe elemen
    # dari literal tuple campuran seperti ini.
    __table_args__: tuple[Any, ...] = (
        CheckConstraint("planned_amount >= 0", name="ck_amort_planned_nonneg"),
        CheckConstraint("actual_amount IS NULL OR actual_amount >= 0", name="ck_amort_actual_nonneg"),
        Index("ix_amort_asset_period", "asset_id", "period_date", unique=True),
        Index("ix_amort_status", "status"),
        {},
    )

    # id diwarisi dari Base (UUID primary key)

    asset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("intangible_asset.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    period_date: Mapped[date] = mapped_column(Date, nullable=False)
    fiscal_year: Mapped[int] = mapped_column(Integer, nullable=False)
    fiscal_period: Mapped[int] = mapped_column(Integer, nullable=False)
    planned_amount: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False)
    actual_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)
    remaining_carrying_value: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)
    status: Mapped[AmortizationStatus] = mapped_column(
        Enum(AmortizationStatus), default=AmortizationStatus.PENDING, nullable=False, index=True
    )
    journal_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("journal_header.id", ondelete="SET NULL"), nullable=True
    )
    journal_entry_number: Mapped[str | None] = mapped_column(String(50), nullable=True)
    adjustment_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)

    def mark_posted(self, actual: Decimal, journal_id: uuid.UUID, journal_number: str) -> None:
        self.actual_amount = actual
        self.journal_id = journal_id
        self.journal_entry_number = journal_number
        self.status = AmortizationStatus.POSTED

    def skip(self, reason: str) -> None:
        self.status = AmortizationStatus.SKIPPED
        self.adjustment_reason = reason

    def adjust(self, new_amount: Decimal, reason: str, journal_id: uuid.UUID, journal_number: str) -> None:
        self.actual_amount = new_amount
        self.adjustment_reason = reason
        self.journal_id = journal_id
        self.journal_entry_number = journal_number
        self.status = AmortizationStatus.ADJUSTED


__all__ = ["AmortizationScheduleTable", "AmortizationStatus"]
